import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';

const STANDARD_HOURS = 8;
const LABOUR_OVERTIME_DEFAULT = 4;

export default function AttendanceMarker({ selectedDate, onDateSelect, onDateReset, selectedEmployee, onEmployeeSelect }) {
  const { employees, markAttendance } = useApp();
  const [status, setStatus] = useState('present');
  const [overtimeHours, setOvertimeHours] = useState(4);
  const [workedHours, setWorkedHours] = useState(STANDARD_HOURS);
  const [message, setMessage] = useState('');

  const selectedEmp = employees.find((e) => e.id === selectedEmployee);
  const isLabour = selectedEmp?.department === 'Labour';
  const showOvertime = selectedEmployee && (status === 'present' || status === 'late');
  const showWorkedHours = selectedEmployee && status === 'late';

  const isToday = selectedDate === new Date().toISOString().slice(0, 10);

  useEffect(() => {
    if (showOvertime) setOvertimeHours(4);
    
    // Reset worked hours to standard when switching away from late or changing employee
    if (!showWorkedHours) setWorkedHours(STANDARD_HOURS);
  }, [selectedEmployee, status, isLabour, showOvertime, showWorkedHours]);

  const handleMark = async () => {
    if (!selectedEmployee) {
      setMessage('Please select an employee');
      return;
    }
    try {
      await markAttendance(
        selectedEmployee,
        selectedDate,
        status,
        showOvertime ? overtimeHours : 0,
        showWorkedHours ? workedHours : null
      );
      setMessage(`Attendance marked for ${selectedDate}`);
      setOvertimeHours(4);
      setWorkedHours(STANDARD_HOURS);
    } catch {
      setMessage('Failed to mark attendance');
    }
    setTimeout(() => setMessage(''), 2000);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 overflow-hidden">
      <div className="p-4 sm:p-5 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between">
        <h3 className="text-base sm:text-lg font-semibold dark:text-gray-100">Mark Attendance</h3>
        {!isToday && (
          <button 
            onClick={onDateReset}
            className="text-xs text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 font-medium"
          >
            Reset to Today
          </button>
        )}
      </div>
      <div className="p-4 sm:p-5 space-y-4">
        <div className="bg-indigo-50/50 dark:bg-indigo-900/10 p-3 rounded-lg border border-indigo-100 dark:border-indigo-900/30 relative">
          <div className="text-[10px] uppercase tracking-wider text-indigo-600 dark:text-indigo-400 font-bold mb-1">Marking Attendance For</div>
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold text-indigo-900 dark:text-indigo-200">
              {new Date(selectedDate).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
            <input 
              type="date" 
              value={selectedDate}
              onChange={(e) => onDateSelect(e.target.value)}
              className="opacity-0 absolute inset-0 w-full h-full cursor-pointer"
              title="Change date"
            />
            <button className="text-indigo-600 dark:text-indigo-400 p-1 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded-full transition-colors relative pointer-events-none">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </button>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Employee</label>
          <select
            value={selectedEmployee}
            onChange={(e) => onEmployeeSelect(e.target.value)}
            className="w-full px-4 py-2.5 sm:py-2 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none text-base sm:text-sm"
          >
            <option value="">Select employee</option>
            {employees.map((emp) => (
              <option key={emp.id} value={emp.id}>{emp.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Status</label>
          <div className="grid grid-cols-2 sm:grid-cols-2 gap-2">
            {[
              { value: 'present', label: 'Present', color: 'border-green-500' },
              { value: 'absent', label: 'Absent', color: 'border-red-500' },
              { value: 'leave', label: 'Leave', color: 'border-amber-500' },
              { value: 'late', label: 'Late', color: 'border-orange-500' },
            ].map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setStatus(opt.value)}
                className={`px-3 py-2.5 rounded-lg border-2 text-sm font-medium transition-all min-h-[44px] sm:min-h-0 ${
                  status === opt.value
                    ? `${opt.color} bg-indigo-50 dark:bg-indigo-900/20 text-indigo-700 dark:text-indigo-400`
                    : 'border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700/50'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
        {showWorkedHours && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Hours Worked (for Late status)
            </label>
            <input
              type="number"
              min={0}
              max={STANDARD_HOURS}
              step={0.5}
              value={workedHours}
              onChange={(e) => setWorkedHours(Math.max(0, Math.min(STANDARD_HOURS, Number(e.target.value) || 0)))}
              className="w-full px-4 py-2.5 sm:py-2 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none text-base sm:text-sm"
              placeholder="e.g. 6"
            />
          </div>
        )}
        {showOvertime && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Overtime (hours) — default 4h
            </label>
            <input
              type="number"
              min={0}
              max={24}
              step={0.5}
              value={overtimeHours}
              onChange={(e) => setOvertimeHours(Math.max(0, Math.min(24, Number(e.target.value) || 0)))}
              className="w-full px-4 py-2.5 sm:py-2 rounded-lg border border-gray-200 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none text-base sm:text-sm"
            />
          </div>
        )}
        {message && (
          <p className={`text-sm ${message.includes('success') ? 'text-green-600 dark:text-green-400' : 'text-amber-600 dark:text-amber-400'}`}>
            {message}
          </p>
        )}
        <button
          type="button"
          onClick={handleMark}
          className="w-full py-3 sm:py-2.5 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 active:bg-indigo-800 transition-colors min-h-[44px] sm:min-h-0"
        >
          Mark Attendance
        </button>
      </div>
    </div>
  );
}
